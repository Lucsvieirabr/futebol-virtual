import{ao as r}from"./CigwaNhF.js";var e=r();export{e as O};
